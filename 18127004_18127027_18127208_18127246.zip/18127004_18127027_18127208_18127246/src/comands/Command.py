
class Command():
    def excute(self):
        raise NotImplementedError()

    def redo(self):
        pass

    def undo(self):
        pass
