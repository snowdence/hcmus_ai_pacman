from .TileManager import TileManager
from .MinimaxManager import MinimaxManager
from .FirstLevelManager import FirstLevelManager
from .SecondLevelManager import SecondLevelManager
from .ThirdLevelManager import ThirdLevelManager
from .FourthLevelManager import FourthLevelManager
