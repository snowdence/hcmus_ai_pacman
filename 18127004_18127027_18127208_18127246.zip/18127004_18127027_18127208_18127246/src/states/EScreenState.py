import enum


class EScreenState():
    PLAYING = 1
    GROUP = 2
    MENU = 3
    MINIMAX = 4
    LEVEL_1 = 5
    LEVEL_2 = 6
    LEVEL_3 = 7
    LEVEL_4 = 8
